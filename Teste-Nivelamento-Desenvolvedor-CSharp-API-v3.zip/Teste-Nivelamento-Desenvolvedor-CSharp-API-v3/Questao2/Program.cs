﻿using Newtonsoft.Json;
using Questao2;
using Refit;
using System;
using System.Net.Http;
using System.Threading.Tasks;
public class Program
{
    static async Task Main()
    {
        string teamName = "Paris Saint-Germain";
        int year = 2013;
        int totalGoals = await GetTotalGoalsAsync(teamName, year);



        Console.WriteLine("Team "+ teamName +" scored "+ totalGoals.ToString() + " goals in "+ year);

        teamName = "Chelsea";
        year = 2014;
        totalGoals = await GetTotalGoalsAsync(teamName, year);

        //getTotalScoredGoals(teamName, year);

        Console.WriteLine("Team " + teamName + " scored " + totalGoals.ToString() + " goals in " + year);

        // Output expected:
        // Team Paris Saint - Germain scored 109 goals in 2013
        // Team Chelsea scored 92 goals in 2014
    }

    //static async Task<int> GetTotalGoalsAsync(string teamName, int year)
    static async Task<int> GetTotalGoalsAsync(string teamName, int year)
    {
        string url = $"https://jsonmock.hackerrank.com/api/football_matches?year={year}&team1={teamName}";
        int totalGoals = 0;

        using (HttpClient client = new HttpClient())
        {
            client.Timeout = TimeSpan.FromSeconds(30); // Ajuste conforme necessário

            try
            {
                HttpResponseMessage response = await client.GetAsync(url);
                response.EnsureSuccessStatusCode(); // Lança uma exceção se o código de status não for bem-sucedido
                string responseData = await response.Content.ReadAsStringAsync();

                var apiResponse = JsonConvert.DeserializeObject<ApiResponse>(responseData);
                foreach (var match in apiResponse.Data)
                {
                    totalGoals += match.Team1Goals;
                }
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine($"Erro ao buscar dados da API: {e.Message}");
            }
            catch (TaskCanceledException e)
            {
                Console.WriteLine("A requisição foi cancelada (possível timeout): " + e.Message);
            }
        }

        return totalGoals;
    }

}