﻿using System;
using System.Globalization;

namespace Questao1
{
    class ContaBancaria {
        private int numero; // numero da conta
        public string titular; // nome do titular da conta
        public double saldo;// saldo presente na conta

        public int getNumero()
        {
            return numero;
        }

        public void setNumero(int numero)
        {
            this.numero = numero;
        }

        public string getTitular()
        {
            return titular;
        }

        public void setTitular(string titular)
        {
            this.titular = titular;
        }

        public double getSaldo()
        {
            return saldo;
        }

        public void setSaldo(double saldo)
        {
            this.saldo = saldo;
        }

        public ContaBancaria(int numero, string titular){
            
            setNumero(numero);
            setTitular(titular);
            setSaldo(0);
        }

    public ContaBancaria(int numero, string titular, double saldo)
    {
            setNumero(numero);
            setTitular(titular);
            setSaldo(saldo);

        }
    
    public void Deposito(double quantia)
        {
            saldo = saldo + quantia;
            return;
        }
    
    public void Saque(double quantia)
        {
            saldo = saldo - quantia;
            saldo = saldo - 3.50;
            return;

        }

    }
}
