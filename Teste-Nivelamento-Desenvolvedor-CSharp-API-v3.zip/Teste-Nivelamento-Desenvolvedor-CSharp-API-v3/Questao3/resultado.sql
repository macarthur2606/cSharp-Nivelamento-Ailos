select assunto,ano,count(*) as quantidade from atendimentos group by assunto,ano order by ano,quantidade desc
