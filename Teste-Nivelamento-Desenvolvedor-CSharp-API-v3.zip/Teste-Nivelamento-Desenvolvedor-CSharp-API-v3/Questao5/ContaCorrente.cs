﻿namespace Questao5
{
    internal class ContaCorrente
    {
        public String idcontacorrente { get; set; }
        public int numero { get; set; }
        public String nome { get; set; }
        public int ativo { get; set; }
    }
}