using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using System.Data.Common;
using Dapper;
using System.Numerics;
using NSubstitute.Core;

namespace Questao5.Infrastructure.Services.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class MovimentacaoContaCorrenteController : ControllerBase
    {

        [HttpPost]
        public IActionResult Post(int idReq, int numero, int valor, String tipomovimento)
        {

            ContaCorrente listConta = new ContaCorrente();

            string connectionString = "Data Source=database.sqlite;";
            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();

                string sql = "SELECT * FROM contacorrente where numero = "+numero;

                IEnumerable<ContaCorrente> cc = connection.Query<ContaCorrente>(sql);

                if (cc.Any())
                {

                    foreach (var contaCorrente in cc)
                    {
                        listConta = contaCorrente;
                    }

                    if (listConta.ativo == 1)
                    {
                        if(valor > 0)
                        {
                            if (tipomovimento.ToUpper() == "C" || tipomovimento.ToUpper() == "D")
                            {
                                // criar o movimento na tabela movimento 
                                connection.Open();

                                var maxIdMovimento = connection.ExecuteScalar<int>("SELECT COALESCE(MAX(idmovimento), 0) FROM movimento");

                                var novoIdMovimento = maxIdMovimento + 1;

                                string insertQuery = @"INSERT INTO [movimento] ([idmovimento],[idcontacorrente] ,[datamovimento] ,[tipomovimento] ,[valor]) VALUES (@novoIdMovimento ,@idcontacorrente , @DateTime , @tipomovimento ,@valor)";

                                var parameters = new  { novoIdMovimento = novoIdMovimento, idcontacorrente = listConta.idcontacorrente, DateTime = DateTime.Now, tipomovimento = tipomovimento.ToUpper(), valor = valor };

                                int rowsAffected = connection.Execute(insertQuery, parameters);
                                Console.WriteLine($"{rowsAffected} linha(s) inserida(s).");

                                return Ok("Movimento gerado: "+novoIdMovimento);
                            }
                            else
                            {
                                return BadRequest("INVALID_TYPE");
                            }
                        }
                        else
                        {
                            return BadRequest("INVALID_VALUE");
                        }
                    }
                    else
                    {
                        return BadRequest("INACTIVE_ACCOUNT");
                    }
                }
                else
                {
                    return BadRequest("INVALID_ACCOUNT");
                }

            }

        }

    }
}