using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using System.Data.Common;
using Dapper;
using System.Numerics;
using NSubstitute.Core;

namespace Questao5.Infrastructure.Services.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class SaldoContaCorrenteController : ControllerBase
    {

        [HttpPost]
        public IActionResult Post(String idcontacorrente)
        {

            var debito = 0; 
            var credito = 0;
            var saldo = 0;
            

            string connectionString = "Data Source=database.sqlite;";
            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();

                string sql = "SELECT * FROM movimento where idcontacorrente = '" + idcontacorrente+"'";

                IEnumerable<Movimento> aa = connection.Query<Movimento>(sql);

                debito = aa.Where(p => p.tipomovimento == "D").Sum(p => p.valor);
                
                credito = aa.Where(p => p.tipomovimento == "C").Sum(p => p.valor);

                saldo = credito - debito;

                connection.Open();

                var numeroConta = connection.ExecuteScalar<int>("SELECT numero FROM contacorrente where idcontacorrente = '" + idcontacorrente + "'");

                connection.Open();

                var titularConta = connection.ExecuteScalar<String>("SELECT nome FROM contacorrente where idcontacorrente = '" + idcontacorrente + "'");

                return Ok("Numero da conta: "+ numeroConta+" nome do titular: "+titularConta+" Data da consulta: "+DateTime.Now+" Saldo: "+saldo);

            }

        }

    }
}