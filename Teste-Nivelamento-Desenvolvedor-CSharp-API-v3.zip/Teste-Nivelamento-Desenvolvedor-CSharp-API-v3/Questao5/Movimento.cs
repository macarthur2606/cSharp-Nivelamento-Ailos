﻿namespace Questao5
{
    internal class Movimento
    {
        public String idmovimento{ get; set; }
        public String idcontacorrente { get; set; }
        public String datamovimento { get; set; }
        public String tipomovimento { get; set; }
        public int valor { get; set; }

    }
}